"""
build.py — compiles the C matrix backend before install.

Run manually:   python build.py
Or via pip:     pip install .   (setuptools calls build_ext automatically)

Strategy:
  1. Try to compile with OpenBLAS + OpenMP (fast path).
  2. If OpenBLAS is not found, fall back to operations_noblastest.c
     (pure C, no extra deps, slower matmul).
"""

import os
import subprocess
import sys
from pathlib import Path

C_DIR = Path(__file__).parent / "type" / "matrix" / "helps-in-c"
OUT   = C_DIR / "lib.so"

WITH_BLAS   = C_DIR / "operations.c"
WITHOUT_BLAS = C_DIR / "operations_noblastest.c"


def run(cmd: list[str]) -> bool:
    """Run a command, return True on success."""
    print(f"  $ {' '.join(cmd)}")
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"  [!] {result.stderr.strip()}")
    return result.returncode == 0


def compile_with_blas() -> bool:
    return run([
        "gcc", "-O3", "-fPIC", "-shared",
        str(WITH_BLAS),
        "-o", str(OUT),
        "-fopenmp",
        "-lopenblas",
    ])


def compile_without_blas() -> bool:
    print("  [i] Falling back to no-BLAS build (matmul will be slower).")
    return run([
        "gcc", "-O3", "-fPIC", "-shared",
        str(WITHOUT_BLAS),
        "-o", str(OUT),
    ])


def build() -> None:
    print("==> Building matrixflowers C backend...")

    if not C_DIR.exists():
        print(f"[!] C source directory not found: {C_DIR}", file=sys.stderr)
        sys.exit(1)

    # Check for gcc
    if subprocess.run(["which", "gcc"], capture_output=True).returncode != 0:
        print("[!] gcc not found. Install it and try again.", file=sys.stderr)
        sys.exit(1)

    if compile_with_blas():
        print("==> Built with OpenBLAS + OpenMP.")
    elif compile_without_blas():
        print("==> Built without OpenBLAS (pure C fallback).")
        print("    Tip: install libopenblas-dev for faster matmul.")
    else:
        print("[!] Compilation failed. Check the errors above.", file=sys.stderr)
        sys.exit(1)

    print(f"==> lib.so written to {OUT}")


# Called by setuptools as a build step
def build_ext(setup_kwargs):
    build()


if __name__ == "__main__":
    build()
