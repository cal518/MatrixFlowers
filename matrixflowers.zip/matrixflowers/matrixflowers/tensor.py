"""
matrixflowers.tensor
==============
Tensor com autograd (grafo dinâmico, estilo TensorFlow Eager / PyTorch).

Cada operação registra quem são os "pais" e como propagar o gradiente
de volta (backward_fn). Ao chamar .backward(), o grafo é percorrido em
ordem topológica e os gradientes são acumulados em .grad.

A Matrix do backend C é usada para o dado numérico; as operações de
autograd ficam aqui no Python.
"""

from __future__ import annotations

import numpy as np
from typing import Optional, Callable
from type.matrix.py_implementation.matrix import Matrix


class Tensor:
    """
    Wrapper sobre Matrix com suporte a diferenciação automática.

    Parâmetros
    ----------
    data : array-like | Matrix | np.ndarray
        Dado inicial (float32).
    requires_grad : bool
        Se True, gradientes serão calculados para este tensor.
    _parents : tuple[Tensor, ...]
        Tensores dos quais este foi derivado (uso interno).
    _backward_fn : Callable | None
        Função que propaga dL/dout para os pais (uso interno).
    label : str
        Nome opcional para debug.
    """

    def __init__(
        self,
        data,
        requires_grad: bool = False,
        _parents: tuple["Tensor", ...] = (),
        _backward_fn: Optional[Callable] = None,
        label: str = "",
    ):
        if isinstance(data, Matrix):
            self._matrix = data
        else:
            self._matrix = Matrix(np.array(data, dtype=np.float32))

        self.requires_grad = requires_grad
        self.grad: Optional[np.ndarray] = None        # dL/d(self)
        self._parents = _parents
        self._backward_fn = _backward_fn
        self.label = label

    # ------------------------------------------------------------------
    # Propriedades de conveniência
    # ------------------------------------------------------------------

    @property
    def data(self) -> np.ndarray:
        return self._matrix.data

    @data.setter
    def data(self, value: np.ndarray):
        self._matrix = Matrix(np.array(value, dtype=np.float32))

    @property
    def shape(self) -> tuple[int, int]:
        return (self._matrix.rows, self._matrix.cols)

    @property
    def T(self) -> "Tensor":
        """Transposta (sem grad — use só pra reshaping manual)."""
        return Tensor(self.data.T, requires_grad=False)

    def numpy(self) -> np.ndarray:
        return self.data

    # ------------------------------------------------------------------
    # Autograd: backward
    # ------------------------------------------------------------------

    def backward(self, grad: Optional[np.ndarray] = None) -> None:
        """
        Dispara o backward pass a partir deste tensor.
        Só pode ser chamado num tensor escalar (loss) ou com `grad` explícito.
        """
        if grad is None:
            if self.data.size != 1:
                raise RuntimeError(
                    "backward() sem argumento só funciona em tensores escalares. "
                    "Passe grad explicitamente para tensores não-escalares."
                )
            grad = np.ones_like(self.data)

        self.grad = grad if self.grad is None else self.grad + grad

        # Ordenação topológica (DFS)
        topo: list[Tensor] = []
        visited: set[int] = set()

        def _build_topo(t: Tensor):
            if id(t) not in visited:
                visited.add(id(t))
                for p in t._parents:
                    _build_topo(p)
                topo.append(t)

        _build_topo(self)

        for t in reversed(topo):
            if t._backward_fn is not None and t.grad is not None:
                t._backward_fn(t.grad)

    def zero_grad(self) -> None:
        self.grad = None

    def _accumulate_grad(self, g: np.ndarray) -> None:
        if self.requires_grad:
            self.grad = g if self.grad is None else self.grad + g

    # ------------------------------------------------------------------
    # Operações — todas retornam novos Tensors com backward_fn
    # ------------------------------------------------------------------

    def __add__(self, other: "Tensor") -> "Tensor":
        other = _ensure_tensor(other)
        out_data = self._matrix.add(other._matrix)
        rg = self.requires_grad or other.requires_grad

        def _bwd(g):
            # grad passa igual pra ambos; reduz eixos se houve broadcast
            self._accumulate_grad(_unbroadcast(g, self.shape))
            other._accumulate_grad(_unbroadcast(g, other.shape))

        return Tensor(out_data, requires_grad=rg, _parents=(self, other), _backward_fn=_bwd)

    def __sub__(self, other: "Tensor") -> "Tensor":
        other = _ensure_tensor(other)
        out_data = self._matrix.sub(other._matrix)
        rg = self.requires_grad or other.requires_grad

        def _bwd(g):
            self._accumulate_grad(_unbroadcast(g, self.shape))
            other._accumulate_grad(_unbroadcast(-g, other.shape))

        return Tensor(out_data, requires_grad=rg, _parents=(self, other), _backward_fn=_bwd)

    def __mul__(self, other: "Tensor") -> "Tensor":
        """Multiplicação element-wise."""
        other = _ensure_tensor(other)
        out_data = self._matrix.mul(other._matrix)
        rg = self.requires_grad or other.requires_grad
        a_data, b_data = self.data.copy(), other.data.copy()

        def _bwd(g):
            self._accumulate_grad(_unbroadcast(g * b_data, self.shape))
            other._accumulate_grad(_unbroadcast(g * a_data, other.shape))

        return Tensor(out_data, requires_grad=rg, _parents=(self, other), _backward_fn=_bwd)

    def __truediv__(self, other: "Tensor") -> "Tensor":
        """Divisão element-wise."""
        other = _ensure_tensor(other)
        out_data = self._matrix.div(other._matrix)
        rg = self.requires_grad or other.requires_grad
        a_data, b_data = self.data.copy(), other.data.copy()

        def _bwd(g):
            self._accumulate_grad(_unbroadcast(g / b_data, self.shape))
            other._accumulate_grad(_unbroadcast(-g * a_data / (b_data ** 2), other.shape))

        return Tensor(out_data, requires_grad=rg, _parents=(self, other), _backward_fn=_bwd)

    def __matmul__(self, other: "Tensor") -> "Tensor":
        """Multiplicação matricial — usa OpenBLAS via C."""
        other = _ensure_tensor(other)
        out_data = self._matrix.matmul(other._matrix)
        rg = self.requires_grad or other.requires_grad
        a_data, b_data = self.data.copy(), other.data.copy()

        def _bwd(g):
            # dL/dA = g @ B^T,  dL/dB = A^T @ g
            self._accumulate_grad(g @ b_data.T)
            other._accumulate_grad(a_data.T @ g)

        return Tensor(out_data, requires_grad=rg, _parents=(self, other), _backward_fn=_bwd)

    # Operações escalares
    def __radd__(self, s): return self.__add__(_scalar_tensor(s, self.shape))
    def __rsub__(self, s): return _scalar_tensor(s, self.shape).__sub__(self)
    def __rmul__(self, s): return self.__mul__(_scalar_tensor(s, self.shape))
    def __neg__(self):     return self.__mul__(_scalar_tensor(-1.0, self.shape))

    def sum(self, axis=None, keepdims=False) -> "Tensor":
        out_np = self.data.sum(axis=axis, keepdims=keepdims)
        if out_np.ndim < 2:
            out_np = out_np.reshape(1, -1) if out_np.ndim == 1 else out_np.reshape(1, 1)
        rg = self.requires_grad

        def _bwd(g):
            self._accumulate_grad(np.broadcast_to(g, self.shape).copy())

        return Tensor(Matrix(out_np.astype(np.float32)), requires_grad=rg,
                      _parents=(self,), _backward_fn=_bwd)

    def mean(self) -> "Tensor":
        n = self.data.size
        s = self.sum()

        def _bwd(g):
            self._accumulate_grad(np.full(self.shape, g.sum() / n, dtype=np.float32))

        out_np = self.data.mean().reshape(1, 1).astype(np.float32)
        rg = self.requires_grad
        return Tensor(Matrix(out_np), requires_grad=rg, _parents=(self,), _backward_fn=_bwd)

    # ------------------------------------------------------------------
    # Utilidades
    # ------------------------------------------------------------------

    def detach(self) -> "Tensor":
        """Retorna cópia sem histórico de gradiente."""
        return Tensor(self.data.copy(), requires_grad=False)

    def __repr__(self) -> str:
        rg = ", requires_grad=True" if self.requires_grad else ""
        label = f", label='{self.label}'" if self.label else ""
        return f"Tensor(shape={self.shape}{rg}{label})"


# ------------------------------------------------------------------
# Helpers internos
# ------------------------------------------------------------------

def _ensure_tensor(x) -> Tensor:
    if isinstance(x, Tensor):
        return x
    return Tensor(np.array([[x]], dtype=np.float32))


def _scalar_tensor(s: float, shape: tuple[int, int]) -> Tensor:
    return Tensor(np.full(shape, s, dtype=np.float32))


def _unbroadcast(g: np.ndarray, shape: tuple[int, int]) -> np.ndarray:
    """Reduz g para `shape` desfazendo broadcast."""
    while g.ndim > 2:
        g = g.sum(axis=0)
    if g.shape == shape:
        return g
    # Reduz linhas se necessário
    if shape[0] == 1 and g.shape[0] > 1:
        g = g.sum(axis=0, keepdims=True)
    # Reduz colunas se necessário
    if shape[1] == 1 and g.shape[1] > 1:
        g = g.sum(axis=1, keepdims=True)
    return g
