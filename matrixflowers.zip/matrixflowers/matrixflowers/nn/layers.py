"""
matrixflowers.nn.layers
=================
Camadas de rede neural no estilo Keras/TensorFlow.

- Dense      : camada totalmente conectada com ativação opcional
- Dropout    : regularização por zeragem aleatória
- Sequential : pilha de camadas com forward/backward automático
"""

from __future__ import annotations

import numpy as np
from typing import Optional

from tensor import Tensor
from model.parameter import Parameter
from type.matrix.py_implementation.matrix import Matrix
from nn.activations import get as get_activation


# ------------------------------------------------------------------
# Classe base
# ------------------------------------------------------------------

class Layer:
    """Interface mínima que toda camada deve seguir."""

    training: bool = True

    def __call__(self, x: Tensor) -> Tensor:
        return self.forward(x)

    def forward(self, x: Tensor) -> Tensor:
        raise NotImplementedError

    def parameters(self) -> list[Parameter]:
        return []

    def trainable_tensors(self) -> list[Tensor]:
        return []

    def train(self) -> None:
        self.training = True

    def eval(self) -> None:
        self.training = False

    def __repr__(self) -> str:
        return self.__class__.__name__


# ------------------------------------------------------------------
# Dense
# ------------------------------------------------------------------

class Dense(Layer):
    """
    Camada totalmente conectada: output = activation(x @ W + b)

    Parâmetros
    ----------
    units : int
        Número de neurônios de saída.
    input_dim : int
        Número de features de entrada.
    activation : str | None
        Nome da ativação ('relu', 'sigmoid', 'tanh', 'softmax', ...) ou None.
    use_bias : bool
        Se True (padrão), inclui viés.
    kernel_initializer : str
        'he_normal' (padrão), 'glorot_uniform', 'zeros'.
    """

    def __init__(
        self,
        units: int,
        input_dim: int,
        activation: Optional[str] = None,
        use_bias: bool = True,
        kernel_initializer: str = "he_normal",
    ):
        self.units = units
        self.input_dim = input_dim
        self.use_bias = use_bias
        self.activation_name = activation

        W_data = _init_kernel(kernel_initializer, input_dim, units)
        self._W = Tensor(W_data, requires_grad=True, label="W")
        self._b = Tensor(
            np.zeros((1, units), dtype=np.float32), requires_grad=True, label="b"
        ) if use_bias else None

        self._act_fn = get_activation(activation) if activation else None

    # -- forward -------------------------------------------------------

    def forward(self, x: Tensor) -> Tensor:
        batch = x.shape[0]

        # z = x @ W   — usa OpenBLAS por baixo via Tensor.__matmul__
        xW = x.__matmul__(self._W)   # (batch, units)

        if self.use_bias:
            # Adiciona bias com backward correto:
            # out[i,j] = xW[i,j] + b[0,j]
            # dL/dxW  = g          (passa igual)
            # dL/db   = g.sum(axis=0, keepdims=True)
            b_data = np.broadcast_to(self._b.data, (batch, self.units)).copy()
            out_data = xW.data + b_data

            rg = xW.requires_grad or self._b.requires_grad
            out = Tensor(out_data, requires_grad=rg, _parents=(xW, self._b))

            _xW, _b = xW, self._b  # captura no closure

            def _out_bwd(g):
                _xW._accumulate_grad(g)
                _b._accumulate_grad(g.sum(axis=0, keepdims=True))

            out._backward_fn = _out_bwd
        else:
            out = xW

        if self._act_fn is not None:
            out = self._act_fn(out)

        return out

    # -- parâmetros ---------------------------------------------------

    def trainable_tensors(self) -> list[Tensor]:
        return [self._W] + ([self._b] if self._b is not None else [])

    def parameters(self) -> list[Parameter]:
        """Compatibilidade com SGD/Adam legado (Parameter-based)."""
        p_W = Parameter(self._W.data)
        p_W.grad = self._W.grad if self._W.grad is not None else np.zeros_like(self._W.data)
        params = [p_W]
        if self._b is not None:
            p_b = Parameter(self._b.data)
            p_b.grad = self._b.grad if self._b.grad is not None else np.zeros_like(self._b.data)
            params.append(p_b)
        return params

    def __repr__(self) -> str:
        act = self.activation_name or "linear"
        return f"Dense(units={self.units}, input_dim={self.input_dim}, activation='{act}')"


# ------------------------------------------------------------------
# Dropout
# ------------------------------------------------------------------

class Dropout(Layer):
    """
    Dropout: zera aleatoriamente `rate` fração das ativações durante treino.
    Em eval(), passa o input sem alteração (inverted dropout).
    """

    def __init__(self, rate: float = 0.5):
        if not 0.0 <= rate < 1.0:
            raise ValueError(f"rate deve estar em [0, 1). Recebido: {rate}")
        self.rate = rate
        self._mask: Optional[np.ndarray] = None

    def forward(self, x: Tensor) -> Tensor:
        if not self.training or self.rate == 0.0:
            return x

        self._mask = (np.random.rand(*x.shape) > self.rate).astype(np.float32) / (1.0 - self.rate)
        out_data = x.data * self._mask
        out = Tensor(out_data, requires_grad=x.requires_grad, _parents=(x,))
        mask = self._mask

        def _bwd(g):
            x._accumulate_grad(g * mask)

        out._backward_fn = _bwd
        return out

    def __repr__(self) -> str:
        return f"Dropout(rate={self.rate})"


# ------------------------------------------------------------------
# Sequential
# ------------------------------------------------------------------

class Sequential(Layer):
    """
    Pilha de camadas executadas em sequência.

    Exemplo
    -------
    >>> model = Sequential([
    ...     Dense(64, input_dim=784, activation='relu'),
    ...     Dropout(0.3),
    ...     Dense(10, input_dim=64, activation='softmax'),
    ... ])
    >>> output = model(x)
    """

    def __init__(self, layers: list[Layer] | None = None):
        self._layers: list[Layer] = layers or []

    def add(self, layer: Layer) -> "Sequential":
        self._layers.append(layer)
        return self

    def forward(self, x: Tensor) -> Tensor:
        for layer in self._layers:
            x = layer(x)
        return x

    def parameters(self) -> list[Parameter]:
        params = []
        for layer in self._layers:
            params.extend(layer.parameters())
        return params

    def trainable_tensors(self) -> list[Tensor]:
        tensors = []
        for layer in self._layers:
            tensors.extend(layer.trainable_tensors())
        return tensors

    def train(self) -> None:
        for layer in self._layers:
            layer.training = True

    def eval(self) -> None:
        for layer in self._layers:
            layer.training = False

    def summary(self) -> None:
        print("=" * 52)
        print(f"{'Layer':<30} {'Output Shape':>20}")
        print("=" * 52)
        total = 0
        for layer in self._layers:
            params = sum(p.data.size for p in layer.parameters())
            total += params
            print(f"{repr(layer):<30} {params:>20,} params")
        print("=" * 52)
        print(f"Total de parâmetros treináveis: {total:,}")
        print("=" * 52)

    def __repr__(self) -> str:
        inner = "\n  ".join(repr(l) for l in self._layers)
        return f"Sequential(\n  {inner}\n)"


# ------------------------------------------------------------------
# Helpers de inicialização
# ------------------------------------------------------------------

def _init_kernel(name: str, fan_in: int, fan_out: int) -> np.ndarray:
    if name == "he_normal":
        std = np.sqrt(2.0 / fan_in)
        return (np.random.randn(fan_in, fan_out) * std).astype(np.float32)
    if name == "glorot_uniform":
        limit = np.sqrt(6.0 / (fan_in + fan_out))
        return np.random.uniform(-limit, limit, (fan_in, fan_out)).astype(np.float32)
    if name == "zeros":
        return np.zeros((fan_in, fan_out), dtype=np.float32)
    raise ValueError(f"Inicializador desconhecido: '{name}'")