"""
matrixflowers.nn.activations
======================
Funções de ativação que funcionam com Tensor (autograd) E com Matrix (legado).

As funções originais de tools/activation.py são preservadas como
*_matrix(x) para compatibilidade. As versões padrão aqui aceitam Tensor
e propagam gradientes automaticamente.
"""

from __future__ import annotations

import numpy as np
from tensor import Tensor
from type.matrix.py_implementation.matrix import Matrix


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

def _to_tensor(x) -> Tensor:
    if isinstance(x, Tensor):
        return x
    if isinstance(x, Matrix):
        return Tensor(x, requires_grad=False)
    return Tensor(np.array(x, dtype=np.float32))


# ------------------------------------------------------------------
# Ativações com autograd
# ------------------------------------------------------------------

def relu(x: Tensor | Matrix) -> Tensor:
    """ReLU: max(0, x)"""
    t = _to_tensor(x)
    mask = (t.data > 0).astype(np.float32)
    out = Tensor(t.data * mask, requires_grad=t.requires_grad, _parents=(t,))

    def _bwd(g):
        t._accumulate_grad(g * mask)

    out._backward_fn = _bwd
    return out

def manu(x: Tensor | Matrix) -> Tensor:
    """Activation: f(x) = x * sin(x)"""

    t = _to_tensor(x)

    out_data = t.data * np.sin(t.data)
    out = Tensor(out_data, requires_grad=t.requires_grad, _parents=(t,))

    def _bwd(g):
        # f'(x) = sin(x) + x*cos(x)
        grad_input = g * (np.sin(t.data) + t.data * np.cos(t.data))
        t._accumulate_grad(grad_input)

    out._backward_fn = _bwd
    return out

def sigmoid(x: Tensor | Matrix) -> Tensor:
    """Sigmoid: 1 / (1 + e^-x)"""
    t = _to_tensor(x)
    s = 1.0 / (1.0 + np.exp(-t.data))
    out = Tensor(s, requires_grad=t.requires_grad, _parents=(t,))

    def _bwd(g):
        t._accumulate_grad(g * s * (1.0 - s))

    out._backward_fn = _bwd
    return out


def tanh(x: Tensor | Matrix) -> Tensor:
    """Tanh: maps to [-1, 1]"""
    t = _to_tensor(x)
    th = np.tanh(t.data)
    out = Tensor(th, requires_grad=t.requires_grad, _parents=(t,))

    def _bwd(g):
        t._accumulate_grad(g * (1.0 - th ** 2))

    out._backward_fn = _bwd
    return out


def softmax(x: Tensor | Matrix) -> Tensor:
    """Softmax (numericamente estável). Sem backward próprio — use com cross_entropy."""
    t = _to_tensor(x)
    shifted = t.data - t.data.max(axis=1, keepdims=True)
    e = np.exp(shifted)
    s = e / e.sum(axis=1, keepdims=True)
    # Nota: backward do softmax sozinho é O(n²); na prática combina-se com
    # cross_entropy e o gradiente combinado é simplesmente (pred - target)/batch.
    return Tensor(s, requires_grad=t.requires_grad, _parents=(t,))


def leaky_relu(x: Tensor | Matrix, alpha: float = 0.01) -> Tensor:
    """Leaky ReLU: permite gradiente pequeno nos negativos."""
    t = _to_tensor(x)
    out_data = np.where(t.data > 0, t.data, alpha * t.data)
    out = Tensor(out_data, requires_grad=t.requires_grad, _parents=(t,))

    def _bwd(g):
        t._accumulate_grad(g * np.where(t.data > 0, 1.0, alpha))

    out._backward_fn = _bwd
    return out


def elu(x: Tensor | Matrix, alpha: float = 1.0) -> Tensor:
    """ELU: Exponential Linear Unit."""
    t = _to_tensor(x)
    out_data = np.where(t.data > 0, t.data, alpha * (np.exp(t.data) - 1.0))
    out = Tensor(out_data, requires_grad=t.requires_grad, _parents=(t,))

    def _bwd(g):
        d = np.where(t.data > 0, 1.0, alpha * np.exp(t.data))
        t._accumulate_grad(g * d)

    out._backward_fn = _bwd
    return out


def linear(x: Tensor | Matrix) -> Tensor:
    """Identidade (sem transformação)."""
    t = _to_tensor(x)
    out = Tensor(t.data.copy(), requires_grad=t.requires_grad, _parents=(t,))

    def _bwd(g):
        t._accumulate_grad(g)

    out._backward_fn = _bwd
    return out


# ------------------------------------------------------------------
# Mapa de nomes → função (útil para Sequential/Dense)
# ------------------------------------------------------------------

ACTIVATIONS: dict[str, callable] = {
    "relu":       relu,
    "sigmoid":    sigmoid,
    "tanh":       tanh,
    "softmax":    softmax,
    "leaky_relu": leaky_relu,
    "elu":        elu,
    "linear":     linear,
    "none":       linear,
    "manu":       manu,
}


def get(name: str) -> callable:
    """Retorna a função de ativação pelo nome."""
    if name not in ACTIVATIONS:
        raise ValueError(f"Ativação desconhecida: '{name}'. Disponíveis: {list(ACTIVATIONS)}")
    return ACTIVATIONS[name]
