"""
example_regression.py — matrixflowers learning f(x) = x^2
====================================================
Teste de regressão contínua (função quadrática).
"""

import numpy as np
import sys
sys.path.insert(0, ".")

from tensor import Tensor
from nn.layers import Sequential, Dense
from train.tape import GradientTape
from train.losses import mse
from train.trainer import Trainer
from train.optimizers import Adam


# --------------------------------------------------
# Dataset: f(x) = x^2
# --------------------------------------------------
X = np.linspace(-2, 2, 200).reshape(-1, 1).astype(np.float32)
y = (X ** 2).astype(np.float32)


# --------------------------------------------------
# Modelo (regressão)
# --------------------------------------------------
model = Sequential([
    Dense(16, input_dim=1, activation="manu"),
    Dense(16, input_dim=16, activation="elu"),
    Dense(1,  input_dim=16, activation="manu"),
])

model.summary()


# --------------------------------------------------
# Trainer (alto nível)
# --------------------------------------------------
optimizer = Adam(model.trainable_tensors(), lr=0.01)

trainer = Trainer(
    model=model,
    optimizer=optimizer,
    loss_fn=mse,
    metrics=["mse"],
)

history = trainer.fit(
    X, y,
    epochs=500,
    batch_size=32,
    verbose=True,
)

print("\nAvaliação final:")
print(trainer.evaluate(X, y))


# --------------------------------------------------
# Previsões
# --------------------------------------------------
print("\nPrevisões (amostra):")
preds = trainer.predict(X)

for i in range(0, len(X), 40):
    print(f"x={X[i][0]: .2f}  y_real={y[i][0]: .3f}  y_pred={preds[i][0]: .3f}")


# --------------------------------------------------
# Treino manual (GradientTape)
# --------------------------------------------------
print("\n--- Treino manual com GradientTape ---")

model2 = Sequential([
    Dense(16, input_dim=1, activation="relu"),
    Dense(16, input_dim=16, activation="relu"),
    Dense(1,  input_dim=16, activation="none"),
])

opt2 = Adam(model2.trainable_tensors(), lr=0.01)

for epoch in range(500):
    xb = Tensor(X, requires_grad=False)
    yb = Tensor(y, requires_grad=False)

    with GradientTape() as tape:
        pred = model2(xb)
        loss = mse(pred, yb)

    tvars = model2.trainable_tensors()
    grads = tape.gradient(loss, tvars)

    for g, v in zip(grads, tvars):
        v.grad = g.data if g is not None else None

    opt2.step()
    opt2.zero_grad()

    if epoch % 100 == 0:
        print(f"  Epoch {epoch:>4}  loss={float(loss.data.flat[0]):.6f}")


# --------------------------------------------------
# Resultado final manual
# --------------------------------------------------
print("\nPrevisões finais (manual):")
final = model2(Tensor(X, requires_grad=False))

for i in range(0, len(X), 40):
    print(f"x={X[i][0]: .2f}  y_real={y[i][0]:.3f}  y_pred={final.data[i][0]:.3f}")