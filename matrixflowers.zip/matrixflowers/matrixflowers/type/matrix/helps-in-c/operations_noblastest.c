#include <stdio.h>

void madd(float* a, float* b, float* out, int rows, int cols) {
    int n = rows * cols;
    for (int i = 0; i < n; i++) out[i] = a[i] + b[i];
}
void msub(float* a, float* b, float* out, int rows, int cols) {
    int n = rows * cols;
    for (int i = 0; i < n; i++) out[i] = a[i] - b[i];
}
void mmul(float* a, float* b, float* out, int rows, int cols) {
    int n = rows * cols;
    for (int i = 0; i < n; i++) out[i] = a[i] * b[i];
}
void mdiv(float* a, float* b, float* out, int rows, int cols) {
    int n = rows * cols;
    for (int i = 0; i < n; i++) out[i] = a[i] / b[i];
}
void msadd(float* a, float s, float* out, int rows, int cols) {
    int n = rows * cols;
    for (int i = 0; i < n; i++) out[i] = a[i] + s;
}
void mssub(float* a, float s, float* out, int rows, int cols) {
    int n = rows * cols;
    for (int i = 0; i < n; i++) out[i] = a[i] - s;
}
void msmul(float* a, float s, float* out, int rows, int cols) {
    int n = rows * cols;
    for (int i = 0; i < n; i++) out[i] = a[i] * s;
}
void msdiv(float* a, float s, float* out, int rows, int cols) {
    int n = rows * cols;
    for (int i = 0; i < n; i++) out[i] = a[i] / s;
}
void msradd(float s, float* a, float* out, int rows, int cols) {
    int n = rows * cols;
    for (int i = 0; i < n; i++) out[i] = s + a[i];
}
void msrsub(float s, float* a, float* out, int rows, int cols) {
    int n = rows * cols;
    for (int i = 0; i < n; i++) out[i] = s - a[i];
}
void msrmul(float s, float* a, float* out, int rows, int cols) {
    int n = rows * cols;
    for (int i = 0; i < n; i++) out[i] = s * a[i];
}
void msrdiv(float s, float* a, float* out, int rows, int cols) {
    int n = rows * cols;
    for (int i = 0; i < n; i++) out[i] = s / a[i];
}
void matmul(float* a, float* b, float* out, int r1, int c1, int c2) {
    for (int i = 0; i < r1; i++)
        for (int j = 0; j < c2; j++) {
            float sum = 0;
            for (int k = 0; k < c1; k++)
                sum += a[i*c1+k] * b[k*c2+j];
            out[i*c2+j] = sum;
        }
}
