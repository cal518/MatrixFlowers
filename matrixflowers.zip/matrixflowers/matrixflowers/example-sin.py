"""
example-sin.py — treino de função não-linear f(x) = x * sin(x)
==============================================================
"""

import numpy as np
import sys
sys.path.insert(0, ".")

from tensor import Tensor
from nn.layers import Sequential, Dense
from train.tape import GradientTape
from train.losses import mse
from train.trainer import Trainer
from train.optimizers import Adam


# ------------------------------------------------------------
# Dataset: f(x) = x * sin(x)
# ------------------------------------------------------------
np.random.seed(42)

X = np.linspace(-10, 10, 200).astype(np.float32).reshape(-1, 1)
y = (X * np.sin(X)).astype(np.float32)

# normalização ajuda MUITO aqui
X_norm = X / 10.0


# ------------------------------------------------------------
# Modelo
# ------------------------------------------------------------
model = Sequential([
    Dense(64, input_dim=1, activation="manu"),
    Dense(64, input_dim=64, activation="manu"),
    Dense(1, input_dim=64, activation="none"),
])

model.summary()


# ------------------------------------------------------------
# Otimizador + Trainer (alto nível)
# ------------------------------------------------------------
optimizer = Adam(model.trainable_tensors(), lr=10)

trainer = Trainer(
    model=model,
    optimizer=optimizer,
    loss_fn=mse,
    metrics=["loss"],
)

history = trainer.fit(
    X_norm, y,
    epochs=800,
    batch_size=32,
    verbose=True,
)


# ------------------------------------------------------------
# Avaliação
# ------------------------------------------------------------
print("\nAvaliação final:")
print(trainer.evaluate(X_norm, y))


# ------------------------------------------------------------
# Teste de previsão
# ------------------------------------------------------------
print("\nPrevisões:")
test_x = np.array([[-8], [-3], [0], [2], [7]], dtype=np.float32)
test_y = test_x * np.sin(test_x)

pred = trainer.predict(test_x / 10.0)

for x, yt, yp in zip(test_x.flatten(), test_y.flatten(), pred.flatten()):
    print(f"x={x:5.2f}  y_real={yt:7.3f}  y_pred={yp:7.3f}")
