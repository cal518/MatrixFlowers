import numpy as np
from .parameter import Parameter


class SGD:
    """
    Stochastic Gradient Descent with optional momentum.

    Update rule (no momentum):
        p = p - lr * grad

    Update rule (with momentum):
        v = momentum * v - lr * grad
        p = p + v
    """

    def __init__(self, parameters: list[Parameter], lr: float = 0.01, momentum: float = 0.0):
        self.parameters = parameters
        self.lr = lr
        self.momentum = momentum
        self._velocity = [np.zeros_like(p.data) for p in parameters]

    def step(self) -> None:
        for p, v in zip(self.parameters, self._velocity):
            if self.momentum:
                v[:] = self.momentum * v - self.lr * p.grad
                p.data += v
            else:
                p.data -= self.lr * p.grad

    def zero_grad(self) -> None:
        for p in self.parameters:
            p.zero_grad()

    def __repr__(self) -> str:
        return f"SGD(lr={self.lr}, momentum={self.momentum})"


class Adam:
    """
    Adam optimizer (Adaptive Moment Estimation).

    Reference: Kingma & Ba, 2015 — https://arxiv.org/abs/1412.6980

    Update rule:
        m = beta1 * m + (1 - beta1) * grad          # 1st moment
        v = beta2 * v + (1 - beta2) * grad²         # 2nd moment
        m̂ = m / (1 - beta1^t)                       # bias correction
        v̂ = v / (1 - beta2^t)
        p = p - lr * m̂ / (sqrt(v̂) + eps)
    """

    def __init__(
        self,
        parameters: list[Parameter],
        lr: float = 1e-3,
        beta1: float = 0.9,
        beta2: float = 0.999,
        eps: float = 1e-8,
        weight_decay: float = 0.0,
    ):
        self.parameters = parameters
        self.lr = lr
        self.beta1 = beta1
        self.beta2 = beta2
        self.eps = eps
        self.weight_decay = weight_decay

        self._t = 0
        self._m = [np.zeros_like(p.data) for p in parameters]
        self._v = [np.zeros_like(p.data) for p in parameters]

    def step(self) -> None:
        self._t += 1
        b1, b2, t = self.beta1, self.beta2, self._t

        bc1 = 1.0 - b1 ** t   # bias correction factor 1
        bc2 = 1.0 - b2 ** t   # bias correction factor 2

        for p, m, v in zip(self.parameters, self._m, self._v):
            g = p.grad

            if self.weight_decay:
                g = g + self.weight_decay * p.data

            m[:] = b1 * m + (1.0 - b1) * g
            v[:] = b2 * v + (1.0 - b2) * (g ** 2)

            m_hat = m / bc1
            v_hat = v / bc2

            p.data -= self.lr * m_hat / (np.sqrt(v_hat) + self.eps)

    def zero_grad(self) -> None:
        for p in self.parameters:
            p.zero_grad()

    def __repr__(self) -> str:
        return (
            f"Adam(lr={self.lr}, beta1={self.beta1}, "
            f"beta2={self.beta2}, eps={self.eps})"
        )
