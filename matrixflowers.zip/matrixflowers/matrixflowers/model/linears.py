import numpy as np
from .parameter import Parameter
from type.matrix.py_implementation.matrix import Matrix


class Linear:
    """
    Fully connected layer: y = x @ W + b

    Supports forward and backward passes for gradient-based training.
    """

    def __init__(self, in_features: int, out_features: int):
        # He initialization for better gradient flow
        scale = np.sqrt(2.0 / in_features)
        self.W = Parameter(np.random.randn(in_features, out_features).astype(np.float32) * scale)
        self.b = Parameter(np.zeros((1, out_features), dtype=np.float32))

        self._x_cache: np.ndarray | None = None

    def forward(self, x: Matrix) -> Matrix:
        self._x_cache = x.data
        out = x.data @ self.W.data + self.b.data
        return Matrix(out)

    def backward(self, grad_output: Matrix) -> Matrix:
        """
        Backpropagates the gradient through this layer.

        Args:
            grad_output: Gradient w.r.t. the output of this layer (dL/dy).

        Returns:
            Gradient w.r.t. the input of this layer (dL/dx).
        """
        if self._x_cache is None:
            raise RuntimeError("backward() called before forward(). Run forward() first.")

        g = grad_output.data  # (batch, out_features)

        self.W.grad += self._x_cache.T @ g          # (in_features, out_features)
        self.b.grad += g.sum(axis=0, keepdims=True)  # (1, out_features)

        grad_input = g @ self.W.data.T               # (batch, in_features)
        return Matrix(grad_input)

    def parameters(self) -> list[Parameter]:
        return [self.W, self.b]

    def __repr__(self) -> str:
        return (
            f"Linear(in_features={self.W.data.shape[0]}, "
            f"out_features={self.W.data.shape[1]})"
        )
