import numpy as np


class Parameter:
    """
    Wraps a numpy array as a trainable parameter with gradient tracking.
    """

    def __init__(self, data):
        self.data = np.array(data, dtype=np.float32)
        self.grad = np.zeros_like(self.data)

    def zero_grad(self):
        self.grad.fill(0.0)

    def __repr__(self):
        return f"Parameter(shape={self.data.shape}, dtype={self.data.dtype})"
