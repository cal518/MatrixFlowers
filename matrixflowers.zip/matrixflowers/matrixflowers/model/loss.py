import numpy as np
from type.matrix.py_implementation.matrix import Matrix


def _validate_shapes(pred: Matrix, target: Matrix) -> None:
    if pred.data.shape != target.data.shape:
        raise ValueError(
            f"Shape mismatch: pred={pred.data.shape}, target={target.data.shape}"
        )


# ── MSE ──────────────────────────────────────────────────────────────────────

def mse(pred: Matrix, target: Matrix) -> float:
    """Mean Squared Error loss."""
    _validate_shapes(pred, target)
    diff = pred.data - target.data
    return float(np.mean(diff ** 2))


def mse_grad(pred: Matrix, target: Matrix) -> Matrix:
    """Gradient of MSE w.r.t. predictions: dL/dpred = 2*(pred - target) / N"""
    _validate_shapes(pred, target)
    n = pred.data.size
    grad = (2.0 / n) * (pred.data - target.data)
    return Matrix(grad.astype(np.float32))


# ── Cross Entropy ─────────────────────────────────────────────────────────────

def cross_entropy(pred: Matrix, target: Matrix) -> float:
    """
    Categorical cross-entropy loss.
    Expects `pred` to be softmax probabilities and `target` to be one-hot encoded.
    """
    _validate_shapes(pred, target)
    eps = 1e-9
    batch_size = pred.data.shape[0]
    clipped = np.clip(pred.data, eps, 1.0 - eps)
    return float(-np.sum(target.data * np.log(clipped)) / batch_size)


def cross_entropy_grad(pred: Matrix, target: Matrix) -> Matrix:
    """
    Gradient for softmax + cross-entropy (combined, numerically stable).
    dL/dlogits = (pred - target) / batch_size
    """
    _validate_shapes(pred, target)
    batch_size = pred.data.shape[0]
    grad = (pred.data - target.data) / batch_size
    return Matrix(grad.astype(np.float32))


# ── Binary Cross Entropy ──────────────────────────────────────────────────────

def binary_cross_entropy(pred: Matrix, target: Matrix) -> float:
    """
    Binary cross-entropy loss for sigmoid outputs.
    Expects values in (0, 1).
    """
    _validate_shapes(pred, target)
    eps = 1e-9
    p = np.clip(pred.data, eps, 1.0 - eps)
    t = target.data
    return float(-np.mean(t * np.log(p) + (1.0 - t) * np.log(1.0 - p)))


def binary_cross_entropy_grad(pred: Matrix, target: Matrix) -> Matrix:
    """Gradient of BCE w.r.t. predictions."""
    _validate_shapes(pred, target)
    eps = 1e-9
    p = np.clip(pred.data, eps, 1.0 - eps)
    t = target.data
    n = pred.data.size
    grad = (-(t / p) + (1.0 - t) / (1.0 - p)) / n
    return Matrix(grad.astype(np.float32))
