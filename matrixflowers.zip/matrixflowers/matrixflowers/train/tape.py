"""
matrixflowers.train.tape
==================
GradientTape — API idêntica à do TensorFlow.

Uso básico
----------
>>> with GradientTape() as tape:
...     pred = model(x)
...     loss = loss_fn(pred, y)
...
>>> grads = tape.gradient(loss, model.trainable_tensors())
>>> optimizer.apply(grads, model.trainable_tensors())

O GradientTape marca os Tensors como requires_grad=True dentro
do bloco `with`, dispara o backward ao sair e coleta os gradientes.
"""

from __future__ import annotations

from typing import Optional
from tensor import Tensor


class GradientTape:
    """
    Contexto que rastreia operações e calcula gradientes.

    Parâmetros
    ----------
    persistent : bool
        Se True, o grafo não é liberado após gradient() — permite
        chamar gradient() mais de uma vez (igual ao TF).
    """

    def __init__(self, persistent: bool = False):
        self.persistent = persistent
        self._loss: Optional[Tensor] = None
        self._watched: list[Tensor] = []

    def __enter__(self) -> "GradientTape":
        return self

    def __exit__(self, *args) -> None:
        pass  # o backward é chamado manualmente via gradient()

    def watch(self, tensor: Tensor) -> None:
        """Força o rastreamento de um tensor (útil para inputs)."""
        tensor.requires_grad = True
        self._watched.append(tensor)

    def gradient(
        self,
        loss: Tensor,
        variables: list[Tensor],
    ) -> list[Optional[Tensor]]:
        """
        Calcula dL/dv para cada variável em `variables`.

        Retorna uma lista de Tensors com os gradientes
        (None se a variável não participou do grafo).
        """
        # Zera gradientes de todas as variáveis antes do backward
        for v in variables:
            v.zero_grad()

        # Dispara o backward a partir da loss
        loss.backward()

        # Coleta gradientes
        grads = []
        for v in variables:
            if v.grad is not None:
                grads.append(Tensor(v.grad.copy(), requires_grad=False))
            else:
                grads.append(None)

        if not self.persistent:
            self._loss = None

        return grads
