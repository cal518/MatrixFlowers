"""
matrixflowers.train.trainer
=====================
API de alto nível para treinar modelos, estilo Keras.

Uso
---
>>> trainer = Trainer(model, optimizer, loss_fn)
>>> history = trainer.fit(X_train, y_train, epochs=10, batch_size=32)
>>> metrics = trainer.evaluate(X_test, y_test)
"""

from __future__ import annotations

import numpy as np
import time
from typing import Callable, Optional

from tensor import Tensor
from train.tape import GradientTape
from nn.layers import Sequential


LossFn = Callable[[Tensor, Tensor], Tensor]


class Trainer:
    """
    Encapsula o loop de treino completo.

    Parâmetros
    ----------
    model : Sequential
        O modelo a treinar.
    optimizer : SGD | Adam
        Otimizador (da model/optimizers.py).
    loss_fn : callable
        Função de loss que recebe (pred: Tensor, target: Tensor) → Tensor escalar.
    metrics : list[str]
        Métricas a reportar: 'accuracy' disponível.
    """

    def __init__(
        self,
        model: Sequential,
        optimizer,
        loss_fn: LossFn,
        metrics: list[str] | None = None,
    ):
        self.model = model
        self.optimizer = optimizer
        self.loss_fn = loss_fn
        self.metrics = metrics or []

    # ------------------------------------------------------------------
    # fit
    # ------------------------------------------------------------------

    def fit(
        self,
        X: np.ndarray,
        y: np.ndarray,
        epochs: int = 10,
        batch_size: int = 32,
        validation_data: tuple[np.ndarray, np.ndarray] | None = None,
        verbose: bool = True,
        callbacks: list | None = None,
    ) -> dict[str, list[float]]:
        """
        Treina o modelo.

        Retorna
        -------
        history : dict
            {'loss': [...], 'val_loss': [...], 'accuracy': [...], ...}
        """
        history: dict[str, list[float]] = {"loss": []}
        if "accuracy" in self.metrics:
            history["accuracy"] = []
        if validation_data:
            history["val_loss"] = []
            if "accuracy" in self.metrics:
                history["val_accuracy"] = []

        n = X.shape[0]
        callbacks = callbacks or []

        for epoch in range(1, epochs + 1):
            self.model.train()
            t0 = time.time()

            # Shuffle
            idx = np.random.permutation(n)
            X_s, y_s = X[idx], y[idx]

            epoch_loss = 0.0
            epoch_correct = 0
            n_batches = 0

            for start in range(0, n, batch_size):
                xb = _to_tensor(X_s[start: start + batch_size])
                yb = _to_tensor(y_s[start: start + batch_size])

                with GradientTape() as tape:
                    pred = self.model(xb)
                    loss = self.loss_fn(pred, yb)

                # Pega tensors treináveis do modelo
                tvars = self.model.trainable_tensors()
                grads = tape.gradient(loss, tvars)

                # Aplica gradientes via otimizador
                _apply_gradients(self.optimizer, grads, tvars)

                epoch_loss += float(loss.data.flat[0])
                n_batches += 1

                if "accuracy" in self.metrics:
                    epoch_correct += _count_correct(pred, yb)

            avg_loss = epoch_loss / n_batches
            history["loss"].append(avg_loss)

            log = f"Epoch {epoch:>4}/{epochs}  loss={avg_loss:.4f}"

            if "accuracy" in self.metrics:
                acc = epoch_correct / n
                history["accuracy"].append(acc)
                log += f"  acc={acc:.4f}"

            if validation_data:
                self.model.eval()
                val_metrics = self.evaluate(*validation_data, batch_size=batch_size)
                history["val_loss"].append(val_metrics["loss"])
                log += f"  val_loss={val_metrics['loss']:.4f}"
                if "accuracy" in self.metrics:
                    history["val_accuracy"].append(val_metrics.get("accuracy", 0.0))
                    log += f"  val_acc={val_metrics.get('accuracy', 0.0):.4f}"

            elapsed = time.time() - t0
            log += f"  [{elapsed:.1f}s]"

            if verbose:
                print(log)

            for cb in callbacks:
                cb(epoch, history)

        return history

    # ------------------------------------------------------------------
    # evaluate
    # ------------------------------------------------------------------

    def evaluate(
        self,
        X: np.ndarray,
        y: np.ndarray,
        batch_size: int = 32,
    ) -> dict[str, float]:
        """Avalia o modelo em dados sem atualizar pesos."""
        self.model.eval()
        total_loss = 0.0
        total_correct = 0
        n_batches = 0
        n = X.shape[0]

        for start in range(0, n, batch_size):
            xb = _to_tensor(X[start: start + batch_size])
            yb = _to_tensor(y[start: start + batch_size])
            pred = self.model(xb)
            loss = self.loss_fn(pred, yb)
            total_loss += float(loss.data.flat[0])
            n_batches += 1

            if "accuracy" in self.metrics:
                total_correct += _count_correct(pred, yb)

        result = {"loss": total_loss / n_batches}
        if "accuracy" in self.metrics:
            result["accuracy"] = total_correct / n

        return result

    # ------------------------------------------------------------------
    # predict
    # ------------------------------------------------------------------

    def predict(self, X: np.ndarray, batch_size: int = 32) -> np.ndarray:
        """Roda inferência e retorna numpy array."""
        self.model.eval()
        preds = []
        for start in range(0, X.shape[0], batch_size):
            xb = _to_tensor(X[start: start + batch_size])
            out = self.model(xb)
            preds.append(out.data)
        return np.concatenate(preds, axis=0)


# ------------------------------------------------------------------
# Helpers internos
# ------------------------------------------------------------------

def _to_tensor(arr: np.ndarray) -> Tensor:
    if arr.ndim == 1:
        arr = arr.reshape(-1, 1)
    return Tensor(arr.astype(np.float32), requires_grad=False)


def _apply_gradients(optimizer, grads, tvars):
    """
    Copia os gradientes calculados pelo GradientTape de volta para os Tensors,
    depois chama step() e zero_grad() do otimizador.
    """
    for grad, var in zip(grads, tvars):
        # grad é um Tensor retornado por tape.gradient(); .data é o np.ndarray
        var.grad = grad.data if grad is not None else None
    optimizer.step()
    optimizer.zero_grad()


def _count_correct(pred: Tensor, target: Tensor) -> int:
    p = np.argmax(pred.data, axis=1)
    t = np.argmax(target.data, axis=1) if target.data.shape[1] > 1 else target.data.ravel().astype(int)
    return int((p == t).sum())