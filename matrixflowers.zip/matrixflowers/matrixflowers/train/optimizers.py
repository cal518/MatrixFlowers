"""
matrixflowers.train.optimizers
========================
Otimizadores que trabalham diretamente com Tensor (autograd).

Os otimizadores de model/optimizers.py continuam intactos para uso
com Parameter/Linear legado. Estes aqui são usados com Sequential/Dense.
"""

from __future__ import annotations

import numpy as np
from tensor import Tensor


class SGD:
    """SGD com momentum opcional — versão para Tensor."""

    def __init__(
        self,
        variables: list[Tensor],
        lr: float = 0.01,
        momentum: float = 0.0,
    ):
        self.variables = variables
        self.lr = lr
        self.momentum = momentum
        self._velocity = [np.zeros_like(v.data) for v in variables]

    def step(self) -> None:
        for var, vel in zip(self.variables, self._velocity):
            if var.grad is None:
                continue
            g = var.grad
            if self.momentum:
                vel[:] = self.momentum * vel - self.lr * g
                var.data = var.data + vel
            else:
                var.data = var.data - self.lr * g

    def zero_grad(self) -> None:
        for var in self.variables:
            var.zero_grad()

    def __repr__(self) -> str:
        return f"SGD(lr={self.lr}, momentum={self.momentum})"


class Adam:
    """
    Adam — versão para Tensor.

    Kingma & Ba 2015: m̂ / (√v̂ + ε)
    """

    def __init__(
        self,
        variables: list[Tensor],
        lr: float = 1e-3,
        beta1: float = 0.9,
        beta2: float = 0.999,
        eps: float = 1e-8,
        weight_decay: float = 0.0,
    ):
        self.variables = variables
        self.lr = lr
        self.beta1 = beta1
        self.beta2 = beta2
        self.eps = eps
        self.weight_decay = weight_decay

        self._t = 0
        self._m = [np.zeros_like(v.data) for v in variables]
        self._v = [np.zeros_like(v.data) for v in variables]

    def step(self) -> None:
        self._t += 1
        b1, b2, t = self.beta1, self.beta2, self._t
        bc1 = 1.0 - b1 ** t
        bc2 = 1.0 - b2 ** t

        for var, m, v in zip(self.variables, self._m, self._v):
            if var.grad is None:
                continue

            g = var.grad.copy()

            if self.weight_decay:
                g = g + self.weight_decay * var.data

            m[:] = b1 * m + (1.0 - b1) * g
            v[:] = b2 * v + (1.0 - b2) * (g ** 2)

            m_hat = m / bc1
            v_hat = v / bc2

            var.data = var.data - self.lr * m_hat / (np.sqrt(v_hat) + self.eps)

    def zero_grad(self) -> None:
        for var in self.variables:
            var.zero_grad()

    def __repr__(self) -> str:
        return f"Adam(lr={self.lr}, beta1={self.beta1}, beta2={self.beta2})"
