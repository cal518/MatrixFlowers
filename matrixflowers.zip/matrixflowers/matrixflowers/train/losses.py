"""
matrixflowers.train.losses
====================
Funções de loss que retornam Tensor com backward automático.
Compatíveis com GradientTape.

As funções originais de model/loss.py (que retornam float/Matrix)
são mantidas lá. Aqui ficam as versões que participam do autograd.
"""

from __future__ import annotations

import numpy as np
from tensor import Tensor


def _ensure(x) -> Tensor:
    if isinstance(x, Tensor):
        return x
    return Tensor(np.array(x, dtype=np.float32))


# ------------------------------------------------------------------
# MSE
# ------------------------------------------------------------------

def mse(pred: Tensor, target: Tensor) -> Tensor:
    """Mean Squared Error — retorna Tensor escalar."""
    pred, target = _ensure(pred), _ensure(target)
    diff = pred - target          # Tensor.__sub__ → autograd
    sq = diff * diff              # Tensor.__mul__
    return sq.mean()              # Tensor.mean → escalar


# ------------------------------------------------------------------
# Cross Entropy (softmax output + one-hot target)
# ------------------------------------------------------------------

def cross_entropy(pred: Tensor, target: Tensor) -> Tensor:
    """
    Categorical cross-entropy. Espera pred = softmax(logits) e target = one-hot.
    Gradiente combinado softmax+CE: (pred - target) / batch_size.
    """
    pred, target = _ensure(pred), _ensure(target)
    eps = 1e-9
    batch_size = pred.shape[0]

    # Forward: -sum(target * log(pred)) / batch
    clipped = np.clip(pred.data, eps, 1.0 - eps)
    loss_val = -np.sum(target.data * np.log(clipped)) / batch_size
    out = Tensor(np.array([[loss_val]], dtype=np.float32),
                 requires_grad=pred.requires_grad,
                 _parents=(pred,))

    def _bwd(g):
        # Gradiente combinado (numericamente estável)
        grad = (pred.data - target.data) / batch_size
        pred._accumulate_grad(g * grad)

    out._backward_fn = _bwd
    return out


# ------------------------------------------------------------------
# Binary Cross Entropy (sigmoid output)
# ------------------------------------------------------------------

def binary_cross_entropy(pred: Tensor, target: Tensor) -> Tensor:
    """BCE para outputs sigmoid (classificação binária)."""
    pred, target = _ensure(pred), _ensure(target)
    eps = 1e-9
    p = np.clip(pred.data, eps, 1.0 - eps)
    t = target.data
    n = pred.data.size

    loss_val = -np.mean(t * np.log(p) + (1.0 - t) * np.log(1.0 - p))
    out = Tensor(np.array([[loss_val]], dtype=np.float32),
                 requires_grad=pred.requires_grad,
                 _parents=(pred,))

    def _bwd(g):
        grad = (-(t / p) + (1.0 - t) / (1.0 - p)) / n
        pred._accumulate_grad(g * grad)

    out._backward_fn = _bwd
    return out


# ------------------------------------------------------------------
# Huber Loss (robusto a outliers)
# ------------------------------------------------------------------

def huber(pred: Tensor, target: Tensor, delta: float = 1.0) -> Tensor:
    """Huber loss: quadrática para erros pequenos, linear para grandes."""
    pred, target = _ensure(pred), _ensure(target)
    diff = pred.data - target.data
    abs_diff = np.abs(diff)
    quadratic = np.minimum(abs_diff, delta)
    linear = abs_diff - quadratic
    loss_val = np.mean(0.5 * quadratic ** 2 + delta * linear)

    out = Tensor(np.array([[loss_val]], dtype=np.float32),
                 requires_grad=pred.requires_grad,
                 _parents=(pred,))

    def _bwd(g):
        grad = np.where(abs_diff <= delta, diff, delta * np.sign(diff)) / pred.data.size
        pred._accumulate_grad(g * grad)

    out._backward_fn = _bwd
    return out
