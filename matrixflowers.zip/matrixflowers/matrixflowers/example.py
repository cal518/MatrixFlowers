"""
example.py — demonstração da API estilo TensorFlow do matrixflowers
=============================================================
Treina um classificador no XOR (clássico problema não-linear).
"""

import numpy as np
import sys
sys.path.insert(0, ".")

from tensor import Tensor
from nn.layers import Sequential, Dense, Dropout
from train.tape import GradientTape
from train.losses import cross_entropy
from train.trainer import Trainer
from train.optimizers import Adam


# ------------------------------------------------------------------
# Dataset: XOR
# ------------------------------------------------------------------
X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]], dtype=np.float32)
y = np.array([[1, 0], [0, 1], [0, 1], [1, 0]], dtype=np.float32)  # one-hot


# ------------------------------------------------------------------
# Modelo estilo Keras
# ------------------------------------------------------------------
model = Sequential([
    Dense(16, input_dim=2, activation="relu"),
    Dense(16, input_dim=16, activation="relu"),
    Dense(2,  input_dim=16, activation="none"),
])

model.summary()

# ------------------------------------------------------------------
# Opção 1 — Trainer (alto nível, igual Keras)
# ------------------------------------------------------------------
optimizer = Adam(model.trainable_tensors(), lr=0.005)

trainer = Trainer(
    model=model,
    optimizer=optimizer,
    loss_fn=cross_entropy,
    metrics=["accuracy"],
)

history = trainer.fit(
    X, y,
    epochs=500,
    batch_size=4,   # dataset inteiro por epoch (XOR tem 4 amostras)
    verbose=True,
)

print("\nAvaliação final:")
print(trainer.evaluate(X, y))

print("\nPrevisões:")
preds = trainer.predict(X)
print("predito: ", np.argmax(preds, axis=1))
print("esperado:", np.argmax(y, axis=1))


# ------------------------------------------------------------------
# Opção 2 — GradientTape manual (controle total, igual TF)
# ------------------------------------------------------------------
print("\n--- Treino manual com GradientTape ---")

model2 = Sequential([
    Dense(16, input_dim=2,  activation="elu"),
    Dense(16, input_dim=16, activation="elu"),
    Dense(2,  input_dim=16, activation="none"),
])

opt2 = Adam(model2.trainable_tensors(), lr=0.005)

for epoch in range(500):
    xb = Tensor(X, requires_grad=False)
    yb = Tensor(y, requires_grad=False)

    with GradientTape() as tape:
        pred = model2(xb)
        loss = cross_entropy(pred, yb)

    tvars = model2.trainable_tensors()
    grads = tape.gradient(loss, tvars)

    for g, v in zip(grads, tvars):
        v.grad = g.data if g is not None else None

    opt2.step()
    opt2.zero_grad()

    if epoch % 100 == 0:
        print(f"  Epoch {epoch:>4}  loss={float(loss.data.flat[0]):.4f}")

print("\nPrevisões (tape manual):")
final = model2(Tensor(X, requires_grad=False))
print("predito: ", np.argmax(final.data, axis=1))
print("esperado:", np.argmax(y, axis=1))