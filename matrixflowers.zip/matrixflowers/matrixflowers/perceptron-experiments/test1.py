import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

# ===== DATASET: y = 2x =====
x = np.linspace(-5, 5, 50)
y = np.sqrt(2) + x

# ===== LOSS =====
def loss(w, b):
    pred = w * x + b
    return np.mean((pred - y) ** 2)

# ===== GRADIENTE =====
def grad(w, b):
    pred = w * x + b
    error = pred - y

    dL_dw = 2 * np.mean(error * x)
    dL_db = 2 * np.mean(error)

    return dL_dw, dL_db

# ===== LOSS SURFACE =====
W = np.linspace(-1, 5, 60)
B = np.linspace(-5, 5, 60)
Wg, Bg = np.meshgrid(W, B)

Z = np.zeros_like(Wg)

for i in range(Wg.shape[0]):
    for j in range(Wg.shape[1]):
        Z[i, j] = loss(Wg[i, j], Bg[i, j])

# ===== FIGURA =====
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

ax.plot_surface(Wg, Bg, Z, cmap='viridis', alpha=0.6)

ax.set_xlabel("W")
ax.set_ylabel("B")
ax.set_zlabel("Loss")

# ===== "BOLA" (parâmetros iniciais) =====
w = np.random.uniform(-1, 5)
b = np.random.uniform(-5, 5)

lr = 0.05  # velocidade da gravidade

print("\n=== GRADIENT DESCENT BALL SIMULATION ===\n")

# ===== LOOP DA FÍSICA =====
for step in range(200):

    L = loss(w, b)
    gw, gb = grad(w, b)

    # atualização tipo física: gravidade = -gradiente
    w -= lr * gw
    b -= lr * gb

    new_L = loss(w, b)

    # desenha a bola
    ax.scatter(w, b, new_L, color="red", s=40)

    print(f"step {step:03d} | w={w:.4f} b={b:.4f} loss={new_L:.6f}")

    plt.draw()
    plt.pause(0.03)

plt.show()