class Perceptron:
    def __init__(self):
        self.w = 1.0
        self.b = 0.0

    def forward(self, x):
        return x * self.w + self.b

    def loss(self, x, y):
        pred = self.forward(x)
        return (pred - y) ** 2


def step(neu, x, y, eps=0.0001):
    base_loss = neu.loss(x, y)

    # candidatos (pequenas perturbações)
    candidates = {
        "no_change": (0, 0),
        "w-": (-eps, 0),
        "w+": (eps, 0),
        "b-": (0, -eps),
        "b+": (0, eps),
        "w-_b-": (-eps, -eps),
        "w-_b+": (-eps, eps),
        "w+_b-": (eps, -eps),
        "w+_b+": (eps, eps),
    }

    best_key = None
    best_loss = float("inf")

    best_w = neu.w
    best_b = neu.b

    for k, (dw, db) in candidates.items():
        w = neu.w + dw
        b = neu.b + db

        pred = x * w + b
        l = (pred - y) ** 2

        if l < best_loss:
            best_loss = l
            best_key = k
            best_w = w
            best_b = b

    neu.w = best_w
    neu.b = best_b

    return {
        "base_loss": base_loss,
        "best_loss": best_loss,
        "chosen_move": best_key,
        "w": neu.w,
        "b": neu.b,
    }

# cria o modelo
p = Perceptron()

# dataset simples (reta y = 2x + 1)
data = [
    (0, 1),
    (1, 3),
    (2, 5),
    (3, 7),
    (4, 9),
]

# treina
for epoch in range(10000):
    total_loss = 0

    for x, y in data:
        out = step(p, x, y)
        total_loss += out["best_loss"]

    if epoch % 100 == 0:
        print(f"epoch {epoch} | loss {total_loss:.6f} | w={p.w:.3f} b={p.b:.3f}")

# teste final
print("\nTESTE FINAL")
for x, y in data:
    pred = p.forward(x)
    print(f"x={x} | real={y} | pred={pred:.3f}")