import time
import random
import numpy as np
import torch

from matrix import Matrix


# ======================================================
# CONFIG
# ======================================================

N = 512
RUNS = 5
print("DEBUG numpy:")
np.__config__.show()
# ======================================================
# DATA
# ======================================================

A = [[random.random() for _ in range(N)] for _ in range(N)]
B = [[random.random() for _ in range(N)] for _ in range(N)]

a = Matrix(A)
b = Matrix(B)

na = np.array(A, dtype=np.float32)
nb = np.array(B, dtype=np.float32)

ta = torch.tensor(na)
tb = torch.tensor(nb)


# ======================================================
# HELPERS
# ======================================================

def bench(fn, name):
    times = []

    # warmup (importante pro torch)
    fn()

    for _ in range(RUNS):
        t0 = time.time()
        fn()
        t1 = time.time()
        times.append(t1 - t0)

    avg = sum(times) / len(times)

    print(f"\n[{name}]")
    print(f"avg: {avg:.6f}s")
    print(f"runs: {times}")


# ======================================================
# PYTHON PURE
# ======================================================

def py_matmul(a, b):
    r1, c1 = len(a), len(a[0])
    c2 = len(b[0])

    out = [[0.0 for _ in range(c2)] for _ in range(r1)]

    for i in range(r1):
        for j in range(c2):
            s = 0.0
            for k in range(c1):
                s += a[i][k] * b[k][j]
            out[i][j] = s

    return out


# ======================================================
# BENCHMARKS
# ======================================================

bench(lambda: py_matmul(A, B), "PYTHON PURE")

bench(lambda: a.matmul(b), "ASMTRIX (C BACKEND)")

bench(lambda: np.matmul(na, nb), "NUMPY")

bench(lambda: torch.matmul(ta, tb), "PYTORCH CPU")


# ======================================================
# SANITY
# ======================================================

print("\nSample output (torch):")
print(torch.matmul(ta, tb)[0][:5])