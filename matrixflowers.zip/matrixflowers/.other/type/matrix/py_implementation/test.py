from matrix import Matrix

a = Matrix([[1,2],[3,4]])
b = Matrix([[5,6],[7,8]])

print(a.add(b))
print(a.sub(b))
print(a.mul(b))
print(a.div(b))

print(a.sadd(10))
print(a.rmul(2))

print(a.matmul(b))