import ctypes
import numpy as np
import os


# ======================================================
# LOAD C LIB
# ======================================================

LIB_PATH = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "../helps-in-c/lib.so")
)

lib = ctypes.CDLL(LIB_PATH)


# ======================================================
# TYPE HELPERS
# ======================================================

F_PTR = ctypes.POINTER(ctypes.c_float)


def ptr(x):
    return x.ctypes.data_as(F_PTR)


# ======================================================
# MATRIX CLASS
# ======================================================

class Matrix:
    def __init__(self, data):
        arr = np.array(data, dtype=np.float32)

        if arr.ndim != 2:
            raise ValueError("Matrix must be 2D")

        self.data = arr
        self.rows, self.cols = arr.shape

    def empty(self):
        return np.zeros((self.rows, self.cols), dtype=np.float32)


    # ==================================================
    # MATRIX + MATRIX (ELEMENTWISE)
    # ==================================================

    def add(self, other):
        out = self.empty()

        lib.madd(ptr(self.data), ptr(other.data), ptr(out),
                 self.rows, self.cols)

        return Matrix(out)

    def sub(self, other):
        out = self.empty()

        lib.msub(ptr(self.data), ptr(other.data), ptr(out),
                 self.rows, self.cols)

        return Matrix(out)

    def mul(self, other):
        out = self.empty()

        lib.mmul(ptr(self.data), ptr(other.data), ptr(out),
                 self.rows, self.cols)

        return Matrix(out)

    def div(self, other):
        out = self.empty()

        lib.mdiv(ptr(self.data), ptr(other.data), ptr(out),
                 self.rows, self.cols)

        return Matrix(out)


    # ==================================================
    # MATRIX + SCALAR
    # ==================================================

    def sadd(self, s):
        out = self.empty()

        lib.msadd(ptr(self.data), ctypes.c_float(s), ptr(out),
                  self.rows, self.cols)

        return Matrix(out)

    def ssub(self, s):
        out = self.empty()

        lib.mssub(ptr(self.data), ctypes.c_float(s), ptr(out),
                  self.rows, self.cols)

        return Matrix(out)

    def smul(self, s):
        out = self.empty()

        lib.msmul(ptr(self.data), ctypes.c_float(s), ptr(out),
                  self.rows, self.cols)

        return Matrix(out)

    def sdiv(self, s):
        out = self.empty()

        lib.msdiv(ptr(self.data), ctypes.c_float(s), ptr(out),
                  self.rows, self.cols)

        return Matrix(out)


    # ==================================================
    # SCALAR + MATRIX
    # ==================================================

    def radd(self, s):
        out = self.empty()

        lib.msradd(ctypes.c_float(s), ptr(self.data), ptr(out),
                   self.rows, self.cols)

        return Matrix(out)

    def rsub(self, s):
        out = self.empty()

        lib.msrsub(ctypes.c_float(s), ptr(self.data), ptr(out),
                   self.rows, self.cols)

        return Matrix(out)

    def rmul(self, s):
        out = self.empty()

        lib.msrmul(ctypes.c_float(s), ptr(self.data), ptr(out),
                   self.rows, self.cols)

        return Matrix(out)

    def rdiv(self, s):
        out = self.empty()

        lib.msrdiv(ctypes.c_float(s), ptr(self.data), ptr(out),
                   self.rows, self.cols)

        return Matrix(out)


    # ==================================================
    # MATRIX MULTIPLICATION
    # ==================================================

    def matmul(self, other):
        out = np.zeros((self.rows, other.cols), dtype=np.float32)

        lib.matmul(
            ptr(self.data),
            ptr(other.data),
            ptr(out),
            self.rows,
            self.cols,
            other.cols
        )

        return Matrix(out)


    # ==================================================
    # DEBUG
    # ==================================================

    def show(self):
        print(self.data)

    def numpy(self):
        return self.data
    
    # ==================================================
    # STRING REPRESENTATION
    # ==================================================

    def __str__(self):
        return str(self.data)

    def __repr__(self):
        return f"Matrix(rows={self.rows}, cols={self.cols})\n{self.data}"