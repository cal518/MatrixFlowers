#include <stdio.h>
#include <omp.h>
#include <cblas.h>

// ======================================================
// MATRIX + MATRIX (elementwise)
// ======================================================

void madd(float* a, float* b, float* out, int rows, int cols) {
    int n = rows * cols;

    #pragma omp parallel for
    for (int i = 0; i < n; i++) {
        out[i] = a[i] + b[i];
    }
}

void msub(float* a, float* b, float* out, int rows, int cols) {
    int n = rows * cols;

    #pragma omp parallel for
    for (int i = 0; i < n; i++) {
        out[i] = a[i] - b[i];
    }
}

void mmul(float* a, float* b, float* out, int rows, int cols) {
    int n = rows * cols;

    #pragma omp parallel for
    for (int i = 0; i < n; i++) {
        out[i] = a[i] * b[i];
    }
}

void mdiv(float* a, float* b, float* out, int rows, int cols) {
    int n = rows * cols;

    #pragma omp parallel for
    for (int i = 0; i < n; i++) {
        out[i] = a[i] / b[i];
    }
}


// ======================================================
// MATRIX + SCALAR
// ======================================================

void msadd(float* a, float s, float* out, int rows, int cols) {
    int n = rows * cols;

    #pragma omp parallel for
    for (int i = 0; i < n; i++) {
        out[i] = a[i] + s;
    }
}

void mssub(float* a, float s, float* out, int rows, int cols) {
    int n = rows * cols;

    #pragma omp parallel for
    for (int i = 0; i < n; i++) {
        out[i] = a[i] - s;
    }
}

void msmul(float* a, float s, float* out, int rows, int cols) {
    int n = rows * cols;

    #pragma omp parallel for
    for (int i = 0; i < n; i++) {
        out[i] = a[i] * s;
    }
}

void msdiv(float* a, float s, float* out, int rows, int cols) {
    int n = rows * cols;

    #pragma omp parallel for
    for (int i = 0; i < n; i++) {
        out[i] = a[i] / s;
    }
}


// ======================================================
// SCALAR + MATRIX
// ======================================================

void msradd(float s, float* a, float* out, int rows, int cols) {
    int n = rows * cols;

    #pragma omp parallel for
    for (int i = 0; i < n; i++) {
        out[i] = s + a[i];
    }
}

void msrsub(float s, float* a, float* out, int rows, int cols) {
    int n = rows * cols;

    #pragma omp parallel for
    for (int i = 0; i < n; i++) {
        out[i] = s - a[i];
    }
}

void msrmul(float s, float* a, float* out, int rows, int cols) {
    int n = rows * cols;

    #pragma omp parallel for
    for (int i = 0; i < n; i++) {
        out[i] = s * a[i];
    }
}

void msrdiv(float s, float* a, float* out, int rows, int cols) {
    int n = rows * cols;

    #pragma omp parallel for
    for (int i = 0; i < n; i++) {
        out[i] = s / a[i];
    }
}


// ======================================================
// MATRIX MULTIPLICATION (OPENBLAS - ULTRA FAST)
// ======================================================

void matmul(float* a, float* b, float* out,
            int r1, int c1, int c2) {

    // OpenBLAS SGEMM
    cblas_sgemm(
        CblasRowMajor,
        CblasNoTrans,
        CblasNoTrans,
        r1,      // M (rows A)
        c2,      // N (cols B)
        c1,      // K (cols A / rows B)
        1.0f,    // alpha
        a,       // A
        c1,      // lda
        b,       // B
        c2,      // ldb
        0.0f,    // beta
        out,     // C
        c2       // ldc
    );
}