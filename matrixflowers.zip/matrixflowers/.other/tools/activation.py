import numpy as np
from type.matrix.py_implementation.matrix import Matrix  # ajusta o import pro teu caminho real


# ======================================================
# ACTIVATION FUNCTIONS
# ======================================================

def relu(x: Matrix) -> Matrix:
    """
    ReLU activation: max(0, x)
    """
    return Matrix(np.maximum(x.data, 0))


def sigmoid(x: Matrix) -> Matrix:
    """
    Sigmoid activation: 1 / (1 + e^-x)
    """
    return Matrix(1 / (1 + np.exp(-x.data)))


def tanh(x: Matrix) -> Matrix:
    """
    Tanh activation: maps to [-1, 1]
    """
    return Matrix(np.tanh(x.data))

def softmax(x: Matrix) -> Matrix:
    """
    Softmax activation: exp(x) / sum(exp(x))
    (estável numericamente)
    """
    shifted = x.data - np.max(x.data, axis=1, keepdims=True)
    exp = np.exp(shifted)
    return Matrix(exp / np.sum(exp, axis=1, keepdims=True))

def leaky_relu(x: Matrix, alpha=0.01) -> Matrix:
    """
    Leaky ReLU: allows small gradient for negative values
    """
    return Matrix(np.where(x.data > 0, x.data, alpha * x.data))

def elu(x: Matrix, alpha=1.0) -> Matrix:
    """
    Exponential Linear Unit (ELU)
    """
    return Matrix(np.where(x.data > 0, x.data, alpha * (np.exp(x.data) - 1)))

def linear(x: Matrix) -> Matrix:
    """
    Identity activation (no change)
    """
    return Matrix(x.data)    

def derivative(fn_name: str):
    if fn_name == "relu":
        return lambda x: Matrix((x.data > 0).astype(np.float32))

    if fn_name == "sigmoid":
        return lambda x: Matrix(sigmoid(x.data) * (1 - sigmoid(x.data)))

    if fn_name == "tanh":
        return lambda x: Matrix(1 - np.tanh(x.data) ** 2)

    if fn_name == "linear":
        return lambda x: Matrix(np.ones_like(x.data))

    if fn_name == "leaky_relu":
        return lambda x, alpha=0.01: Matrix(np.where(x.data > 0, 1, alpha))

    raise ValueError("Unknown activation")